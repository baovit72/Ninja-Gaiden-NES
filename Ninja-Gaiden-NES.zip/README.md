# Ninja-Gaiden-NES
A remake of the NES game Ninja Gaiden in C++.
